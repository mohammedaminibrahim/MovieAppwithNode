const express = require('express');
const app = express();
const path = require('path');
const request = require('request');

//middlewares
app.set('views', path.join(__dirname,'views'));
app.set('view engine','ejs');

app.use(express.static('public'));



// main route
app.get('/search',(req,res)=>{
    res.render('search')
});

// result route
app.get('/results',(req,res)=>{

    let query = req.query.search;
    request('https://api.themoviedb.org/3/search/movie?api_key=cbd8e106d81e506050767f519d707657&query='+query,(error,response,body)=>{
        if(error){
            console.log(error);
        }

        let data = JSON.parse(body);
        res.render('movies', {data:data, serchQuery:query});
    })

});


app.listen(3000,()=>{
    console.log("Connected to Port 3000");
});